<?php
 
class Category
{
	public $category_id;
    public $category;
    public $created_at;
    public $is_deleted;


    // constructor
    function __construct() 
    {

    }
 
    // destructor
    function __destruct() 
    {
         
    }
}
 
?>