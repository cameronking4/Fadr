//
//  CategorySearchViewController.h
//  RestaurantLocator
//
//
//  Copyright (c) 2014 Mangasaur Games. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CategorySearchDelegate <NSObject>

-(void)didSelectCategory:(Category1*)category categoryName:(NSString*)categoryName;

@end

@interface CategorySearchViewController : UIViewController <MGListViewDelegate> {
    
    id <CategorySearchDelegate> _categorySearchDelegate;
}

@property (nonatomic, retain) id <CategorySearchDelegate> categorySearchDelegate;


@property (nonatomic, retain) IBOutlet MGListView* listView;

@end
