//
//  Favorite.m
//  RestaurantLocator
//
//  
//  Copyright (c) 2014 Mangasaur Games. All rights reserved.
//

#import "Favorite.h"


@implementation Favorite

@dynamic restaurant_id;

@end
