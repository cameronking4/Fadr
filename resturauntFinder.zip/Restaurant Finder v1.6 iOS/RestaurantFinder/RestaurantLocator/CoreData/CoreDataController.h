//
//  CoreDataController.h
//  RestaurantLocator
//
//  
//  Copyright (c) 2014 Mangasaur Games. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreDataController : NSObject

+(NSArray*) getRestaurants;
+(void) deleteAllObjects:(NSString *) entityDescription;
+(Version*) getVersion;
+(NSArray*) getPhotos;
+(NSArray*) getCategories;
+(NSArray*) getRestaurantsByCategoryId:(NSString*)categoryId;
+(NSMutableArray*) getCategoryNames;
+(NSArray*) getFeaturedRestaurants;
+(NSArray*) getPhotosByRestaurantId:(NSString*)restaurantId;
+(Photo*) getPhotoByRestaurantId:(NSString*)restaurantId;

+(NSArray*) getFavoriteRestaurants;
+(Restaurant*) getRestaurantByRestaurantId:(NSString*)restaurantId;
+(Favorite*) getFavoriteByRestaurantId:(NSString*)restaurantId;
+(Category1*) getCategoryByCategory:(NSString*)category;

+(Category1*) getCategoryByCategoryId:(NSString*)categoryId;
+(Category1*) createInstanceCategory:(NSDictionary*)dictionary;
+(Photo*) getPhotoByPhotoId:(NSString*)photoId;
+(Photo*) createInstancePhoto:(NSDictionary*)dictionary;
+(Restaurant*) createInstanceRestaurant:(NSDictionary*)dictionary;

@end
