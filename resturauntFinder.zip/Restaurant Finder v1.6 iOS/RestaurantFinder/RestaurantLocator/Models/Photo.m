//
//  Photo.m
//  RestaurantLocator
//
//  
//  Copyright (c) 2014 Mangasaur Games. All rights reserved.
//

#import "Photo.h"


@implementation Photo

@dynamic created_at;
@dynamic photo_id;
@dynamic photo_url;
@dynamic restaurant_id;
@dynamic thumb_url;

@end
