//
//  AppDelegate.h
//  RestaurantLocator
//
//  
//  Copyright (c) 2014 Mangasaur Games. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@class AppDelegate;

@protocol LocationDelegate <NSObject>

-(void) appDelegate:(AppDelegate*)appDelegate locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation
       fromLocation:(CLLocation *)oldLocation;

-(void) appDelegate:(AppDelegate*)appDelegate locationManager: (CLLocationManager *)manager didFailWithError: (NSError *)error;

@optional
-(void) appDelegate:(AppDelegate*)appDelegate sensorError: (CLLocationManager *)manager;

@end

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    
    id <LocationDelegate> _locationDelegate;
}

@property (strong, retain) id <LocationDelegate> locationDelegate;

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

@property (nonatomic, strong) RestaurantViewController* contentViewController;
@property (nonatomic, strong) SideViewController* sideViewController;

-(void) saveContext;
+(AppDelegate*) instance;

-(void)findMyCurrentLocation;

-(void)setFilterDistance:(float)distance;
-(float)getFilterDistance;

-(void)setFilterDistanceMax:(float)distance;
-(float)getFilterDistanceMax;

@property (nonatomic, strong) CLLocation* myLocation;

@end
