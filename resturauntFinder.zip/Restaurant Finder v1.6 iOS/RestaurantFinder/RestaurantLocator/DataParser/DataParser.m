

#import "DataParser.h"
#import "AppDelegate.h"


@implementation DataParser

+(NSDictionary*) getJSONAtURL:(NSString*)urlStr {
    
    NSError *error = nil;
    NSError *errorJSON = nil;
    
    NSURL* url = [NSURL URLWithString:urlStr];
    NSData* data = [NSData dataWithContentsOfURL:url options:NSDataReadingMappedAlways | NSDataReadingUncached error:&error];
    NSDictionary* resultsDictionary = [data objectFromJSONDataWithParseOptions:JKParseOptionLooseUnicode error:&errorJSON];
    
    if(error != nil)
        NSLog(@"getJSONAtURL ERROR** = %@", error.localizedDescription);
    
    if(errorJSON != nil)
        NSLog(@"getJSONAtURL ERROR** = %@", errorJSON.localizedDescription);
    
    return resultsDictionary;
}


@end
