

#import <UIKit/UIKit.h>

@interface MGTopLeftLabel : UILabel

@end
