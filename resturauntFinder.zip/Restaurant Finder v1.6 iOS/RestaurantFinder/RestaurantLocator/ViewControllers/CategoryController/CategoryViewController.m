//
//  RestaurantViewController.m
//  RestaurantLocator
//
//  
//  Copyright (c) 2014 Mangasaur Games. All rights reserved.
//

#import "CategoryViewController.h"
#import "AppDelegate.h"
#import "RestaurantViewController.h"
#import "FavoritesViewController.h"
#import "AppDelegate.h"
#import "DetailsViewController.h"

@interface CategoryViewController ()

@end

@implementation CategoryViewController

@synthesize listView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.titleView = [MGUIAppearance createLogo:HEADER_LOGO];
    self.view.backgroundColor = BG_VIEW_COLOR;
    [MGUIAppearance enhanceNavBarController:self.navigationController
                               barTintColor:WHITE_TEXT_COLOR
                                  tintColor:WHITE_TEXT_COLOR
                             titleTextColor:WHITE_TEXT_COLOR];
    
    
    listView.delegate = self;
    
    BOOL screen = IS_IPHONE_6_PLUS_AND_ABOVE;
    int height = screen ? 55 : 50;
    listView.cellHeight = height;
    
    [listView registerNibName:@"CategoryCell" cellIndentifier:@"CategoryCell"];
    [listView baseInit];
    
    NSArray* restaurantsArray = [CoreDataController getRestaurants];
    if(![MGUtilities hasInternetConnection] && (restaurantsArray == nil || [restaurantsArray count] == 0) ) {
        [MGUtilities showAlertTitle:LOCALIZED(@"NETWORK_ERRORNETWORK_ERROR_MSG") message:LOCALIZED(@"")];
        return;
    }
    
    UIBarButtonItem* itemMenu = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:BUTTON_MENU]
                                                                 style:UIBarButtonItemStylePlain
                                                                target:self
                                                                action:@selector(didClickBarButtonMenu:)];

    self.navigationItem.leftBarButtonItem = itemMenu;
    
    [self getCategories];
    
    if(SHOW_ADS_CATEGORY_VIEW) {
        [MGUtilities createAdAtY:self.view.frame.size.height - AD_BANNER_HEIGHT
                  viewController:self
                         bgColor:AD_BG_COLOR];
        
        UIEdgeInsets inset = listView.tableView.contentInset;
        inset.bottom = ADV_VIEW_OFFSET;
        listView.tableView.contentInset = inset;
        
        inset = listView.tableView.scrollIndicatorInsets;
        inset.bottom = ADV_VIEW_OFFSET;
        listView.tableView.scrollIndicatorInsets = inset;
    }
}

-(void)didClickBarButtonMenu:(id)sender {
    AppDelegate* delegate = [AppDelegate instance];
    [delegate.sideViewController updateUI];
    [self.slidingViewController anchorTopViewToRightAnimated:YES];
}

-(void)getCategories {
    if(listView.arrayData == nil)
        listView.arrayData = [NSMutableArray new];
    
    [listView.arrayData removeAllObjects];
    listView.arrayData = [NSMutableArray arrayWithArray:[CoreDataController getCategories]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void) MGListView:(MGListView *)_listView didSelectCell:(MGListCell *)cell indexPath:(NSIndexPath *)indexPath {
    RestaurantViewController* vc = [self.storyboard instantiateViewControllerWithIdentifier:@"storyboardRestaurant"];
    vc.category = listView.arrayData[indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
}

-(UITableViewCell*)MGListView:(MGListView *)listView1 didCreateCell:(MGListCell *)cell indexPath:(NSIndexPath *)indexPath {
    if(cell != nil) {
        Category1* res = [listView.arrayData objectAtIndex:indexPath.row];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell.labelTitle setText:[res.category stringByDecodingHTMLEntities]];
        
        cell.selectedColor = THEME_COLOR;
        cell.unSelectedColor = LIST_TEXT_COLOR;
        
        UIImage* unSelected = [UIImage imageNamed:CATEGORY_LIST_BG];
        UIImage* selected = [UIImage imageNamed:CATEGORY_LIST_BG_SELECTED];
        cell.selectedImage = selected;
        cell.unselectedImage = unSelected;
        cell.unselectedImageArrow = [UIImage imageNamed:LIST_ARROW_NORMAL];
        cell.selectedImageArrow = [UIImage imageNamed:LIST_ARROW_SELECTED];
    }
    return cell;
}

#pragma mark - Navigation


-(IBAction)didClickBarButtonFave:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main_iPhone" bundle:nil];
    FavoritesViewController *viewController = [storyboard instantiateViewControllerWithIdentifier:@"storyboardFavorites"];
    viewController.willNotShowMenu = YES;
    [self.navigationController pushViewController:viewController animated:YES];
}

-(IBAction)didClickBarButtonHome:(id)sender {
    AppDelegate* delegate = [AppDelegate instance];
    UITabBarController *tabBar = (UITabBarController *)delegate.window.rootViewController;
    [tabBar setSelectedIndex:0];
}




@end
