//
//  Restaurant.m
//  RestaurantLocator
//
//  
//  Copyright (c) 2014 Mangasaur Games. All rights reserved.
//

#import "Restaurant.h"


@implementation Restaurant

@dynamic address;
@dynamic amenities;
@dynamic created_at;
@dynamic desc1;
@dynamic email;
@dynamic featured;
@dynamic food_rating;
@dynamic hours;
@dynamic lat;
@dynamic lon;
@dynamic name;
@dynamic phone;
@dynamic price_rating;
@dynamic restaurant_id;
@dynamic website;
@dynamic category_id;
@dynamic distance;


//- (NSString *)name
//{
//    [self willAccessValueForKey:@"name"];
//    NSString *myName = [self name];
//    [self didAccessValueForKey:@"name"];
//    return myName;
//}

@end
