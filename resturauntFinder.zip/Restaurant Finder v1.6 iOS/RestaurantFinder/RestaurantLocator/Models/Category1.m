//
//  Category.m
//  RestaurantLocator
//
//  
//  Copyright (c) 2014 Mangasaur Games. All rights reserved.
//

#import "Category1.h"


@implementation Category1

@dynamic category;
@dynamic category_id;
@dynamic created_at;

@end
