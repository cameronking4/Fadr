

#import <UIKit/UIKit.h>

@interface MGRawScrollView : UIScrollView

@property(nonatomic, retain) UIImageView* imageView;

@end
