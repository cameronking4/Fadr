

#ifndef RestaurantLocator_UIConfig_h
#define RestaurantLocator_UIConfig_h


#define GALLERY_BORDER_WIDTH 3.0f
#define GALLERY_BORDER_RADIUS 6.0f

#define TOP_BAR_OFFSET -64

#define NAV_BAR_OFFSET 50

#define ADV_VIEW_OFFSET 50

#define NAV_BAR_OFFSET_DEFAULT 0


#define THEME_COLOR [UIColor colorWithRed:248.0/255.0 green:58.0/255.0 blue:58.0/255.0 alpha:1.0]

#define NORMAL_COLOR [UIColor colorWithRed:167.0/255.0 green:169.0/255.0 blue:172.0/255.0 alpha:1.0]

#define BG_VIEW_COLOR [UIColor colorWithRed:255.0/255.0 green:243.0/255.0 blue:243.0/255.0 alpha:1.0]

#define WHITE_TEXT_COLOR [UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:1.0]

#define LIST_TEXT_COLOR [UIColor colorWithRed:124.0/255.0 green:124.0/255.0 blue:124.0/255.0 alpha:1.0]

#define THEME_BLACK_TINT_COLOR [UIColor colorWithRed:48.0/255.0 green:48.0/255.0 blue:48.0/255.0 alpha:1.0]

#define BG_SIDE_VIEW_COLOR [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0]

#define NAV_BAR_BG @"nav_bar.png"
#define TAB_BAR_BG @"tabbar.png"
#define TOOL_BAR_BG @"tabbar.png"

#define CATEGORY_LIST_BG @"list_background.png"
#define CATEGORY_LIST_BG_SELECTED @"list_background.png"

#define LIST_ARROW_NORMAL @"list_arrow.png"
#define LIST_ARROW_SELECTED @"list_arrow_selected.png"

#define LIST_BG @"list_background_restaurant.png"
#define LIST_BG_SELECTED @"list_background_restaurant.png"

#define MAP_PIN @"map_pin.png"

#define MAP_ARROW_RIGHT @"map_arrow_right.png"

#define GALLERY_THUMB_PLACEHOLDER_IMAGE @"gallery_image_placeholder.png"

#define IMAGE_VIEWER_PLACEHOLDER_IMAGE @"image_viewer_placeholder.png"

#define RESTAURANT_THUMB_PLACEHOLDER_IMAGE @"thumb_bg.png"

#define SLIDER_PLACEHOLDER_IMAGE @"detail_placeholder.png"

#define INNER_TAB_LEFT_SELECTED @"inner_tab_left_selected.png"
#define INNER_TAB_MIDDLE_SELECTED @"inner_tab_middle_selected.png"
#define INNER_TAB_RIGHT_SELECTED @"inner_tab_right_selected.png"

#define INNER_TAB_LEFT @"inner_tab_left.png"
#define INNER_TAB_MIDDLE @"inner_tab_middle.png"
#define INNER_TAB_RIGHT @"inner_tab_right.png"


#define RATING_STAR_EMPTY @"star_empty.png"
#define RATING_STAR_FULL @"star_fill.png"
#define RATING_STAR_HALF @"star_half.png"

#define FEATURED_BADGE @"ic_list_featured.png"

#define HEADER_LOGO @"header_logo.png"

#define ICON_FAVORITE_ADD @"ic_fave_add.png"

#define ICON_FAVORITE_REMOVE @"ic_fave_remove.png"

#define ICON_LIST_FAVORITE_BADGE @"ic_list_fave.png"

#define ICON_CATEGORIES @"ic_restaurant.png"

#define ICON_HOME @"ic_menu_home.png"

#define ICON_FAVORITES @"ic_menu_fave.png"

#define ICON_FEATURED @"ic_featured.png"

#define ICON_SEARCH @"ic_search.png"

#define ICON_MAP @"ic_map.png"

#define ICON_GALLERIES @"ic_gallery.png"

#define ICON_SETTINGS @"ic_settings.png"

#define SIDE_BAR_CELL_SELECTED @"side_bar_list_bg_selected.png"
#define SIDE_BAR_CELL_NORMAL @"side_bar_list_bg.png"

#define BUTTON_MENU @"ic_menu.png"

#define BUTTON_FAVE @"ic_fave.png"

// DO NOT EDIT THIS
#define ANCHOR_LEFT_PEEK 44.0

// DO NOT EDIT THIS
#define ANCHOR_RIGHT_PEEK 276.0

#define GALLERIES_NUMBER_OF_COLUMNS 4

#define GALLERIES_SPACING 4

#define WILL_DOWNLOAD_DATA YES

typedef enum {
    kMenuAnimationOpen = 0,
    kMenuAnimationClosed = 1
}kMenuAnimation;

#endif
