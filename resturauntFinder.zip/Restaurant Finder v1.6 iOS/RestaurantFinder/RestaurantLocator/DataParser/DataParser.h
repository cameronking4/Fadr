

#import <Foundation/Foundation.h>
#import "TBXMLEx.h"

@interface DataParser : MGParser

+(NSDictionary*) getJSONAtURL:(NSString*)urlStr;

@end
