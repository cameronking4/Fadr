

#import <Foundation/Foundation.h>

@interface UIImage (Extras)

-(UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize;

@end
