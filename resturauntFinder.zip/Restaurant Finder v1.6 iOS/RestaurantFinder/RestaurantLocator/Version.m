//
//  Version.m
//  RestaurantLocator
//
//  
//  Copyright (c) 2014 Mangasaur Games. All rights reserved.
//

#import "Version.h"


@implementation Version

@dynamic version_id;
@dynamic restaurants;
@dynamic photos;
@dynamic categories;

@end
