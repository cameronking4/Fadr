

#ifndef RestaurantLocator_Config_h
#define RestaurantLocator_Config_h

// You AdMob Banner Unit ID
#define BANNER_UNIT_ID @"ca-app-pub-1616470634359992/2091423063"

// Change this url depending on the name of your web hosting.
#define BASE_URL @"http://fadrcuts.com/locator/"

// SETTING TO NO WILL DISPLAY TEST ADS
// SETTING TO YES WILL REMOVE ALL TEST ADS
#define REMOVE_TEST_ADS YES

// Specify test ads id here
// To add another id follow this format
// [NSArray arrayWithObjects:kGADSimulatorID, @"DEVICE_ID", nil]
#define TEST_ADS_ID [NSArray arrayWithObjects:kGADSimulatorID, nil]

// Server API KEY
// This key must match in the Config.php file
#define API_KEY @"45090dcae2aYMK"

// Default restaurants to fetch to get initial data
#define DEFAULT_RESTAURANTS_COUNT_TO_FIND_DISTANCE 20

// Category all text in searching
#define CATEGORY_ALL LOCALIZED(@"All")

// Inner Tab titles inside detail view
#define INNER_TAB_TITLE [NSArray arrayWithObjects:LOCALIZED(@"DETAILS"), LOCALIZED(@"MAP"), LOCALIZED(@"GALLERY"), nil]

// Max filter distance in kilometers
#define MAX_RADIUS_IN_KM 5000

// AdMob background color
#define AD_BG_COLOR [UIColor clearColor]

// AdMob banner height
#define AD_BANNER_HEIGHT 50

// Show Ads in Home
#define SHOW_ADS_HOME_VIEW YES

// Show Ads in Category
#define SHOW_ADS_CATEGORY_VIEW YES

// Show Ads in Category Search
#define SHOW_ADS_CATEGORY_SEARCH_VIEW YES

// Show Ads in Details
#define SHOW_ADS_DETAIL_VIEW YES

// Show Ads in Favroties
#define SHOW_ADS_FAVORITES_VIEW YES

// Show Ads in Featured
#define SHOW_ADS_FEATURED_VIEW YES

// Show Ads in Gallery
#define SHOW_ADS_GALLERY_VIEW YES

// Show Ads in Map
#define SHOW_ADS_MAP_VIEW YES

// Show Ads in Restaurant
#define SHOW_ADS_RESTAURANT_VIEW YES

// Show Ads in Search
#define SHOW_ADS_SEARCH_VIEW YES

#define AUTO_ADJUST_DISTANCE YES

// DO NOT EDIT THIS
#define GET_DATA_URL [NSString stringWithFormat:@"%@%@", BASE_URL, @"rest/get_data.php"]

#endif
