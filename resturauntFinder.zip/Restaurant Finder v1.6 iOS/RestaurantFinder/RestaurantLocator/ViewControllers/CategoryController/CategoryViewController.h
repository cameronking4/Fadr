//
//  RestaurantViewController.h
//  RestaurantLocator
//
//  
//  Copyright (c) 2014 Mangasaur Games. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoryViewController : UIViewController <MGListViewDelegate> {

}

@property (nonatomic, retain) IBOutlet MGListView* listView;
-(IBAction)didClickBarButtonFave:(id)sender;
-(IBAction)didClickBarButtonHome:(id)sender;

@end
